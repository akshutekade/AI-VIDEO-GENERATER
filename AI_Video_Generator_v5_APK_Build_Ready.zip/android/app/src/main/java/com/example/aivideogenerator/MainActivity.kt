package com.example.aivideogenerator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale

private const val API="http://10.0.2.2:8000"

data class ProjectRow(val id:String,val title:String,val status:String,val videoUrl:String)

class MainActivity:ComponentActivity(){
 private var speechCallback:((String)->Unit)?=null
 private val speechLauncher=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){r->
  if(r.resultCode==Activity.RESULT_OK){val text=r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty();speechCallback?.invoke(text)}
 }
 fun startSpeech(cb:(String)->Unit){
  speechCallback=cb
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
   requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),44);return
  }
  val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());putExtra(RecognizerIntent.EXTRA_PROMPT,"Tell your story")}
  speechLauncher.launch(i)
 }
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App(this)}}
}

@Composable fun App(activity:MainActivity){
 var email by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var token by remember{mutableStateOf("")}
 var story by remember{mutableStateOf("")};var status by remember{mutableStateOf("")};var projects by remember{mutableStateOf(listOf<ProjectRow>())};var generating by remember{mutableStateOf(false)}
 fun request(path:String,method:String,body:String?=null,auth:Boolean=false,done:(String)->Unit){
  CoroutineScope(Dispatchers.IO).launch{try{val client=OkHttpClient();val rb=body?.toRequestBody("application/json".toMediaType());val b=Request.Builder().url(API+path);if(method=="POST")b.post(rb?:"{}".toRequestBody("application/json".toMediaType()))else b.get();if(auth)b.header("Authorization","Bearer $token");val r=client.newCall(b.build()).execute();val s=r.body?.string().orEmpty();if(!r.isSuccessful)throw Exception(s);withContext(Dispatchers.Main){done(s)}}catch(e:Exception){withContext(Dispatchers.Main){status=e.message?:"Request failed"}}}
 }
 fun refresh(){request("/projects","GET",auth=true){body->val a=JSONObject(body).getJSONArray("projects");projects=List(a.length()){i->val p=a.getJSONObject(i);ProjectRow(p.getString("id"),p.getString("title"),p.optString("status"),p.optString("video_url"))}}}
 fun poll(id:String){CoroutineScope(Dispatchers.IO).launch{repeat(180){delay(3000);try{val req=Request.Builder().url(API+"/projects/$id").header("Authorization","Bearer $token").get().build();val s=OkHttpClient().newCall(req).execute().body?.string().orEmpty();val p=JSONObject(s);val st=p.optString("status");withContext(Dispatchers.Main){status="Status: $st";if(st=="completed"){generating=false;refresh()};if(st=="failed"){generating=false}};if(st=="completed"||st=="failed")return@launch}catch(_:Exception){}}}}
 if(token.isBlank()){
  Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("AI Video Generator",style=MaterialTheme.typography.headlineMedium);Text("Create AI Shorts from your own narration.");OutlinedTextField(email,{email=it},Modifier.fillMaxWidth(),label={Text("Email")});OutlinedTextField(password,{password=it},Modifier.fillMaxWidth(),label={Text("Password")});Button({request("/auth/register","POST",JSONObject().put("email",email).put("password",password).toString()){status="Account created; sign in now."}},Modifier.fillMaxWidth()){Text("Create account")};Button({request("/auth/login","POST",JSONObject().put("email",email).put("password",password).toString()){token=JSONObject(it).getString("access_token");status="Signed in"}},Modifier.fillMaxWidth()){Text("Sign in")};Text(status)}
 }else{
  Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Text("Create AI Video",style=MaterialTheme.typography.headlineSmall)
   OutlinedTextField(story,{story=it},Modifier.fillMaxWidth().height(180.dp),label={Text("Tell your story / narration")})
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({activity.startSpeech{t->story=if(story.isBlank())t else "$story $t"}},Modifier.weight(1f)){Text("🎙 Speak")};Button({story=""},Modifier.weight(1f)){Text("Clear")}}
   Button({generating=true;status="Starting AI generation...";request("/projects","POST",JSONObject().put("title","AI Short").put("story",story).toString(),true){body->val id=JSONObject(body).getString("id");request("/projects/$id/generate","POST","{}",true){status="Generating AI scenes + voice...";poll(id)} }},Modifier.fillMaxWidth(),enabled=story.isNotBlank()&&!generating){Text(if(generating)"Generating..." else "✨ Generate Video")}
   Button({refresh()},Modifier.fillMaxWidth()){Text("Refresh My Projects")}
   if(status.isNotBlank())Text(status)
   if(projects.isNotEmpty()){Text("My Projects",style=MaterialTheme.typography.titleMedium);LazyColumn{items(projects){p->Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Column(Modifier.padding(12.dp)){Text(p.title);Text(p.status);if(p.videoUrl.isNotBlank()&&p.status=="completed"){Button({activity.startActivity(Intent(Intent.ACTION_VIEW).apply{setDataAndType(android.net.Uri.parse(p.videoUrl),"video/mp4")})}){Text("▶ Preview / Open Video")}}}}}}}
  }
 }
}
