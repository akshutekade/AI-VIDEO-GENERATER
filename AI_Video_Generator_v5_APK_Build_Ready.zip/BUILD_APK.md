# Build the APK

This project includes a GitHub Actions workflow that builds the Android APK in the cloud.

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository (the `android` folder must be at the repository root).
3. Open **Actions → Build Android APK → Run workflow**.
4. When it finishes, open the workflow run and download the artifact **AI-Video-Generator-debug**.
5. Extract it to get `app-debug.apk` and install it on Android.

For a real phone, set the backend HTTPS URL in `android/app/src/main/java/com/example/aivideogenerator/MainActivity.kt` before building.
