import os, uuid, time, sqlite3, shutil, tempfile, subprocess, json
from pathlib import Path
from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from jose import jwt, JWTError
from passlib.context import CryptContext
from dotenv import load_dotenv
import requests

load_dotenv()
JWT_SECRET=os.getenv("JWT_SECRET","change-me")
RUNWAY_KEY=os.getenv("RUNWAYML_API_SECRET")
OPENAI_KEY=os.getenv("OPENAI_API_KEY")
OPENAI_TEXT_MODEL=os.getenv("OPENAI_TEXT_MODEL","gpt-5.6-luna")
OPENAI_TTS_MODEL=os.getenv("OPENAI_TTS_MODEL","gpt-4o-mini-tts")
OPENAI_TTS_VOICE=os.getenv("OPENAI_TTS_VOICE","alloy")
PUBLIC=os.getenv("PUBLIC_BASE_URL","http://localhost:8000")
DB=os.getenv("DB_PATH","app.db")
OUT=Path("outputs"); OUT.mkdir(exist_ok=True)
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto")
bearer=HTTPBearer()
app=FastAPI(title="AI Video Generator API",version="0.5")

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

with db() as c:
 c.execute("CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE,password TEXT)")
 c.execute("CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,user_id TEXT,title TEXT,story TEXT,status TEXT,video_url TEXT,created_at TEXT)")
 c.commit()

class Auth(BaseModel): email:str; password:str
class ProjectIn(BaseModel): title:str="AI Video"; story:str

def token(uid): return jwt.encode({"sub":uid},JWT_SECRET,algorithm="HS256")
def user(creds:HTTPAuthorizationCredentials=Depends(bearer)):
 try:return jwt.decode(creds.credentials,JWT_SECRET,algorithms=["HS256"])["sub"]
 except JWTError:raise HTTPException(401,"Invalid token")

@app.get("/health")
def health(): return {"ok":True,"runway":bool(RUNWAY_KEY),"openai":bool(OPENAI_KEY)}

@app.post("/auth/register")
def register(a:Auth):
 if len(a.password)<6: raise HTTPException(400,"Password must be at least 6 characters")
 uid=uuid.uuid4().hex
 try:
  with db() as c:c.execute("INSERT INTO users VALUES(?,?,?)",(uid,a.email.lower(),pwd.hash(a.password)));c.commit()
 except sqlite3.IntegrityError: raise HTTPException(409,"Email already registered")
 return {"ok":True}

@app.post("/auth/login")
def login(a:Auth):
 with db() as c:u=c.execute("SELECT * FROM users WHERE email=?",(a.email.lower(),)).fetchone()
 if not u or not pwd.verify(a.password,u["password"]): raise HTTPException(401,"Invalid email or password")
 return {"access_token":token(u["id"])}

@app.post("/projects")
def create(p:ProjectIn,uid=Depends(user)):
 if not p.story.strip(): raise HTTPException(400,"Story is required")
 pid=uuid.uuid4().hex
 with db() as c:c.execute("INSERT INTO projects VALUES(?,?,?,?,?,?,datetime('now'))",(pid,uid,p.title,p.story,"draft",""));c.commit()
 return {"id":pid}

@app.get("/projects")
def projects(uid=Depends(user)):
 with db() as c: rows=c.execute("SELECT id,title,status,video_url,created_at FROM projects WHERE user_id=? ORDER BY created_at DESC",(uid,)).fetchall()
 return {"projects":[dict(x) for x in rows]}

@app.get("/projects/{pid}")
def project(pid:str,uid=Depends(user)):
 with db() as c:p=c.execute("SELECT id,title,status,video_url,created_at FROM projects WHERE id=? AND user_id=?",(pid,uid)).fetchone()
 if not p: raise HTTPException(404,"Project not found")
 return dict(p)

def plan(story):
 if not OPENAI_KEY:
  xs=[x.strip() for x in story.replace("!","。").replace("?","。").replace(".","。").split("。") if x.strip()]
  return xs[:8] or [story]
 from openai import OpenAI
 client=OpenAI(api_key=OPENAI_KEY)
 r=client.responses.create(model=OPENAI_TEXT_MODEL,input=f"""Split this story into 4-8 short visual scenes. Return ONLY a JSON array of concise scene descriptions. Keep characters, clothing and visual style consistent across all scenes. Story: {story}""")
 try:
  value=json.loads(r.output_text)
  return value if isinstance(value,list) else [story]
 except: return [story]

def runway(prompt):
 if not RUNWAY_KEY: raise RuntimeError("RUNWAYML_API_SECRET not configured")
 h={"Authorization":f"Bearer {RUNWAY_KEY}","Content-Type":"application/json","X-Runway-Version":"2024-11-06"}
 body={"model":"gen4.5","promptText":prompt,"ratio":"768:1280","duration":5}
 r=requests.post("https://api.dev.runwayml.com/v1/image_to_video",headers=h,json=body,timeout=60)
 if r.status_code>=400: raise RuntimeError(r.text)
 tid=r.json()["id"]
 for _ in range(180):
  s=requests.get(f"https://api.dev.runwayml.com/v1/tasks/{tid}",headers=h,timeout=30).json()
  if s.get("status")=="SUCCEEDED":
   o=s.get("output") or []; return o[0] if isinstance(o,list) else o
  if s.get("status") in ("FAILED","CANCELLED"): raise RuntimeError(str(s))
  time.sleep(2)
 raise RuntimeError("Runway timeout")

def make_tts(text,out):
 if not OPENAI_KEY: return False
 r=requests.post("https://api.openai.com/v1/audio/speech",headers={"Authorization":f"Bearer {OPENAI_KEY}","Content-Type":"application/json"},json={"model":OPENAI_TTS_MODEL,"voice":OPENAI_TTS_VOICE,"input":text[:4096],"response_format":"mp3"},timeout=120)
 if r.status_code>=400: raise RuntimeError(f"OpenAI TTS: {r.text}")
 out.write_bytes(r.content); return True

def video_duration(path):
 r=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(path)],capture_output=True,text=True,check=True)
 return float(r.stdout.strip())

def worker(pid,uid,story):
 work=Path(tempfile.mkdtemp(prefix=pid));clips=[]
 try:
  with db() as c:c.execute("UPDATE projects SET status='processing' WHERE id=? AND user_id=?",(pid,uid));c.commit()
  scenes=plan(story)
  for i,scene in enumerate(scenes):
   prompt=f"Vertical 9:16 family-friendly cinematic AI video. Consistent characters, faces and clothing across scenes. Natural motion, expressive faces, rich lighting, no text, logos or watermark. Scene: {scene}"
   u=runway(prompt);p=work/f"{i}.mp4"
   with requests.get(u,stream=True,timeout=180) as r:
    r.raise_for_status()
    with open(p,"wb") as f:
     for ch in r.iter_content(1024*1024):
      if ch:f.write(ch)
   clips.append(p)
  lst=work/"list.txt"
  with open(lst,"w") as f:
   for p in clips:f.write(f"file '{p.resolve()}'\n")
  silent=work/"silent.mp4"
  subprocess.run(["ffmpeg","-y","-f","concat","-safe","0","-i",str(lst),"-c","copy",str(silent)],check=True,capture_output=True)
  narration=work/"narration.mp3"
  final=OUT/f"{pid}.mp4"
  if make_tts(story,narration):
   dur=video_duration(silent)
   subprocess.run(["ffmpeg","-y","-i",str(silent),"-i",str(narration),"-filter_complex",f"[1:a]apad,atrim=0:{dur}[a]","-map","0:v:0","-map","[a]","-c:v","copy","-c:a","aac","-shortest",str(final)],check=True,capture_output=True)
  else:
   shutil.copy2(silent,final)
  url=f"{PUBLIC}/videos/{final.name}"
  with db() as c:c.execute("UPDATE projects SET status='completed',video_url=? WHERE id=? AND user_id=?",(url,pid,uid));c.commit()
 except Exception as e:
  print("Generation failed:",e)
  with db() as c:c.execute("UPDATE projects SET status='failed' WHERE id=? AND user_id=?",(pid,uid));c.commit()
 finally: shutil.rmtree(work,ignore_errors=True)

@app.post("/projects/{pid}/generate")
def generate(pid:str,bg:BackgroundTasks,uid=Depends(user)):
 with db() as c:p=c.execute("SELECT * FROM projects WHERE id=? AND user_id=?",(pid,uid)).fetchone()
 if not p: raise HTTPException(404,"Project not found")
 if not RUNWAY_KEY: raise HTTPException(500,"Runway key missing")
 bg.add_task(worker,pid,uid,p["story"])
 return {"status":"queued","project_id":pid}

from fastapi.staticfiles import StaticFiles
app.mount("/videos",StaticFiles(directory=str(OUT)),name="videos")
