# Backend deployment

1. Linux VPS/server with Python 3.11+ and FFmpeg.
2. `python -m venv .venv && source .venv/bin/activate`
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and set `JWT_SECRET`, `RUNWAYML_API_SECRET`, `OPENAI_API_KEY`, and `PUBLIC_BASE_URL`.
5. Run: `uvicorn main:app --host 0.0.0.0 --port 8000`
6. Put HTTPS reverse proxy in front of the API.
7. Change Android `API` to the HTTPS backend URL and build the app.

For production scale, replace SQLite with PostgreSQL, local video storage with object storage, and add rate limits, per-user credits, email verification, password reset, abuse controls and a real job queue.
