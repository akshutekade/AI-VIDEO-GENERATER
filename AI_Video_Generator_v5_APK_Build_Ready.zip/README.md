# AI Video Generator v0.5

Android + FastAPI app for turning a typed or spoken story into a vertical AI video.

## v0.5 features
- Email registration/login
- Type a story or use the phone microphone with Android speech recognition
- AI scene planning
- Runway Gen-4.5 vertical video generation
- Automatic AI narration using OpenAI TTS when `OPENAI_API_KEY` is configured
- FFmpeg combines scenes and narration into one MP4
- Project history and live status polling
- Preview/open completed MP4 from Android
- API keys remain on the backend

## Important
This package is source code, not a precompiled APK. A real deployment needs a backend server, API keys and an Android build environment. Runway/OpenAI usage is paid according to the providers' current pricing.

For a physical Android phone, change `API` in `MainActivity.kt` from the emulator address to your HTTPS backend URL.
